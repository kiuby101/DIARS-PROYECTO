package com.loli.demo.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.loli.demo.models.entity.Carrito;

public interface ICarritoDao  extends CrudRepository<Carrito, Long>{

}
